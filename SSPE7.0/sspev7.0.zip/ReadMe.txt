///////////////////SSPE SHADER BY @RyFol\\\\\\\\\\\\\\\\\\\\\


All Code in this shader belongs to RyFol unless stated otherwise in the credits section.

None of this code is to be edited or redistributed without consent




//////////////////////////////// CREDITS \\\\\\\\\\\\\\\\\\\\\\\\\\\\\


Cloud Code - Zheka Smirnov and Steikey (KMPE Dev's) 